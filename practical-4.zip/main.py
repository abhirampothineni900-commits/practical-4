import time

def iterative_linear_search(arr, target):
    for i in range(len(arr)):
        if arr[i] == target:
            return i
    return -1


# User input
n = int(input("Enter the number of elements: "))

arr = []
print("Enter the elements:")
for i in range(n):
    arr.append(int(input(f"Element {i + 1}: ")))

target = int(input("Enter the element to search: "))


# Measure execution time
start_time = time.perf_counter()

result = iterative_linear_search(arr, target)

end_time = time.perf_counter()


# Display result
if result != -1:
    print(f"Element {target} found at index {result}.")
else:
    print(f"Element {target} not found.")

execution_time = end_time - start_time
print(f"Execution Time: {execution_time:.10f} seconds")


# Time Complexity
print("Time Complexity: O(n)")
print("Space Complexity: O(1)")